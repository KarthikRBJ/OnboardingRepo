﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Custom_Pages.Models
{
    public class Workspace
    {
        public int artifactId { get; set; }
        public string  name { get; set; }
    }
}