﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Relativity.API;
using CP = Relativity.CustomPages.ConnectionHelper;
using DTOs = kCura.Relativity.Client.DTOs;
using CORE = RelativityAppCore;
using kCura.Relativity.Client;
using System.Data;
using Custom_Pages.Models;
using System.Data.Common;
using Relativity.Services.Objects;
using Relativity.Services.Objects.DataContracts;
using System.Threading.Tasks;

namespace Custom_Pages.Controllers
{
    public class HomeController : Controller
    {
        

        //
        // GET: /Home/
        public ActionResult CommentList()
        {
            List<CORE.DAL.Entities.Comment> comments= new List<CORE.DAL.Entities.Comment>();

            try
            {
                using (IRSAPIClient proxy =
                                    CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
                {
                    int workspaceId = CP.Helper().GetActiveCaseID();
                    proxy.APIOptions.WorkspaceID = workspaceId;
                    CORE.BLL.Service.RSAPIService.CommentRSAPIService CRSAPIservice = new CORE.BLL.Service.RSAPIService.CommentRSAPIService(proxy);
                    comments = CRSAPIservice.GetAll().ToList();

                    //CORE.BLL.Service.RSAPIService.WorkspaceRSAPIService workspaceService = new CORE.BLL.Service.RSAPIService.WorkspaceRSAPIService(proxy);
                    string message = "Comment Data";
                    ViewBag.Message = message;


                }


            }

            catch (Exception ex)
            {
                ViewBag.Message = ex.ToString();
            }
           // return View(comments);
            return Json(comments, JsonRequestBehavior.AllowGet);
        }
        public ActionResult DocumentList()
        {
            List<CORE.DAL.Entities.Document> documents = new List<CORE.DAL.Entities.Document>();

            try
            {
                using (IRSAPIClient proxy =
                                    CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
                {
                    int workspaceId = CP.Helper().GetActiveCaseID();
                    proxy.APIOptions.WorkspaceID = workspaceId;
                    CORE.BLL.Service.RSAPIService.DocumentRSAPIService CRSAPIservice = new CORE.BLL.Service.RSAPIService.DocumentRSAPIService(proxy);
                    documents = CRSAPIservice.GetAll().ToList();
                    foreach (CORE.DAL.Entities.Document d in documents)
                    {
                        d.Comments = GetCommentChilds(d.Comments.ToList());
                    }
                }


            }

            catch (Exception ex)
            {
                ViewBag.Message = ex.ToString();
            }
             //return View(documents);
            return Json(documents, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetCommentReplys(int artifactId)
        {
            List<CORE.DAL.Entities.Comment> childs = new List<CORE.DAL.Entities.Comment>();
            List<CORE.DAL.Entities.Comment> newChilds = new List<CORE.DAL.Entities.Comment>();
            using (IRSAPIClient proxy =
                                CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
            {
                int workspaceId = CP.Helper().GetActiveCaseID();
                proxy.APIOptions.WorkspaceID = workspaceId;
                CORE.BLL.Service.RSAPIService.CommentRSAPIService cRSAPIService = new CORE.BLL.Service.RSAPIService.CommentRSAPIService(proxy);
                CORE.BLL.Service.SqlService.CommentSqlService commentService = new CORE.BLL.Service.SqlService.CommentSqlService(CP.Helper().GetDBContext(workspaceId));
                childs = commentService.GetCommentsChild(artifactId);

                foreach (var child in childs)
                {
                    CORE.DAL.Entities.Comment comment= cRSAPIService.Get(child.ArtifactId);
                    newChilds.Add(comment);
                }
            }

            return Json(newChilds, JsonRequestBehavior.AllowGet);
        }
        public List<CORE.DAL.Entities.Comment> GetCommentChilds(List<CORE.DAL.Entities.Comment> comments)
        {
            List<CORE.DAL.Entities.Comment> childs = new List<CORE.DAL.Entities.Comment>();
            List<CORE.DAL.Entities.Comment> newChilds = new List<CORE.DAL.Entities.Comment>();
            using (IRSAPIClient proxy =
                                CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
            {
                int workspaceId = CP.Helper().GetActiveCaseID();
                proxy.APIOptions.WorkspaceID = workspaceId;
                CORE.BLL.Service.RSAPIService.CommentRSAPIService cRSAPIService = new CORE.BLL.Service.RSAPIService.CommentRSAPIService(proxy);
                CORE.BLL.Service.SqlService.CommentSqlService commentService = new CORE.BLL.Service.SqlService.CommentSqlService(CP.Helper().GetDBContext(workspaceId));
                foreach (CORE.DAL.Entities.Comment item in comments)
                {
                    childs = commentService.GetCommentsChild(item.ArtifactId);


                    if (!childs.Count().Equals(0))
                    {
                        foreach (CORE.DAL.Entities.Comment child in childs)
                        {
                            CORE.DAL.Entities.Comment comment = cRSAPIService.Get(child.ArtifactId);
                            newChilds.Add(comment);
                        }
                        item.CommentChilds = GetCommentChilds(newChilds);


                    }
                    else
                    {
                        item.CommentChilds= childs;
                    }


                }


            }
            return comments;

        }
        public ActionResult Index(int artifacId)
        {
             CORE.DAL.Entities.Comment comment = new CORE.DAL.Entities.Comment(artifacId);
             List<CORE.DAL.Entities.Comment> commentChild = new List<CORE.DAL.Entities.Comment>();
        //Available Session variables
            var userID = Session["UserID"];
            var email = Session["Email"];
            var workspaceID = Session["WorkspaceID"];
            var firstName = Session["FirstName"];
            var lastName = Session["LastName"];

            try
            {



                //Setting up an RSAPI Client
                using (IRSAPIClient proxy =
                                CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
                {
                    int workspaceId = CP.Helper().GetActiveCaseID();
                    proxy.APIOptions.WorkspaceID = workspaceId;
                    CORE.BLL.Service.RSAPIService.CommentRSAPIService CRSAPIservice = new CORE.BLL.Service.RSAPIService.CommentRSAPIService(proxy);
                    CORE.BLL.Service.SqlService.CommentSqlService CSQLService = new CORE.BLL.Service.SqlService.CommentSqlService(CP.Helper().GetDBContext(workspaceId));
                    commentChild = CSQLService.GetCommentsChild(artifacId);
                    comment = CRSAPIservice.Get(artifacId);
                    
                    List<CORE.DAL.Entities.Comment> comments = new List<CORE.DAL.Entities.Comment>();
                    foreach (var item in commentChild)
                    {
                        comments.Add(CRSAPIservice.Get(item.ArtifactId));
                    }
                    comment.CommentChilds = comments;
                    //CORE.BLL.Service.RSAPIService.WorkspaceRSAPIService workspaceService = new CORE.BLL.Service.RSAPIService.WorkspaceRSAPIService(proxy);
                    string message = "Comment Data";
                    ViewBag.Message = message;
                   

                }
                


            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.ToString();
            }
            return View(comment);


        }

        public ActionResult getTheme()
        {
            DataRowCollection data;
            Theme theme = new Theme();
            using (IRSAPIClient proxy = CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
            {
                int workspace = CP.Helper().GetActiveCaseID();
                IDBContext dbContext = CP.Helper().GetDBContext(-1);
                string sql = $@"SELECT 
                                 
                                  [Value]
                                  
                              FROM 
                                    [eddsdbo].[InstanceSetting]
                              WHERE 
                                    Name LIKE '%Theme UI (light/dark)%'";
                 data = dbContext.ExecuteSqlStatementAsDataTable(sql).Rows;
                foreach (DataRow item in data)
                {
                    foreach (var d in item.ItemArray)
                    {
                       
                        theme.textValue = (string)d;
                       
                    }
                }
                theme.value = theme.textValue.Equals("true") ? true : false;
                theme.textValue = theme.value ? "LIGHT" : "DARK";
            }

            return Json (theme, JsonRequestBehavior.AllowGet);
        }

        public ActionResult changeTheme(string value)
        {
            int data;
            bool response = false;
            using (IRSAPIClient proxy = CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
            {
                
                int workspace = CP.Helper().GetActiveCaseID();
                IDBContext dbContext = CP.Helper().GetDBContext(-1);
                string sql = $@"UPDATE [eddsdbo].[InstanceSetting]
                          SET [Value] = '{value}'
                          WHERE 
                          [Name] LIKE '%Theme UI (light/dark)%'";
                data = dbContext.ExecuteNonQuerySQLStatement(sql);
            }
            

            return Json(data, JsonRequestBehavior.AllowGet);
        }


        public ActionResult getCommentAudit(int commentId)
        {
            List<AuditComment> audit = new List<AuditComment>();
            DataRowCollection data;
            using (IRSAPIClient proxy = CP.Helper().GetServicesManager().CreateProxy<IRSAPIClient>(ExecutionIdentity.System))
            {
                int workspace = CP.Helper().GetActiveCaseID();
                IDBContext dbContext = CP.Helper().GetDBContext(workspace);
                string sql = $@"SELECT TOP (1000) [ArtifactId]
                                  ,[CommentId]
                                  ,[CreatedOn]
                                  ,[CreateByUserId]
                                  ,[CreatedByUserName]
                                  ,[ModifiedOn]
                                  ,[ModifiedByUserId]
                                  ,[ModifiedByUserName]
                                  ,[ReplysAmount]
                                  ,[comment]
                                  ,[type]
                              FROM [EDDSDBO].[AuditComment]
                              WHERE [CommentId] ={commentId};";
                data = dbContext.ExecuteSqlStatementAsDataTable(sql).Rows;
                foreach (DataRow item in data)
                {
                    AuditComment commentAudit = new AuditComment();
                    commentAudit.commentId = (int)item.ItemArray[1];
                    commentAudit.createdOn = (item.ItemArray[2]).ToString();
                    commentAudit.createByUserId = commentAudit.createdOn == string.Empty ? 0 :(int)item.ItemArray[3];
                    commentAudit.createdByUserName = commentAudit.createdOn == string.Empty ? "" : (string)item.ItemArray[4];
                    commentAudit.modifiedOn = (item.ItemArray[5]).ToString();
                    commentAudit.modifiedByUserId = commentAudit.createdOn == string.Empty?(int)item.ItemArray[6]:0;
                    commentAudit.modifiedByUserName = commentAudit.createdOn == string.Empty ? (string)item.ItemArray[7]:"";
                    commentAudit.replysAmount = (int)item.ItemArray[8];
                    commentAudit.comment = (string)item.ItemArray[9];
                    commentAudit.type = (string)item.ItemArray[10];
                    audit.Add(commentAudit);
                }
            }
            return Json(audit, JsonRequestBehavior.AllowGet);
            
        }

        public ActionResult GetDocumentByArtifactID(int DocumentAI)
        {
            string date;
            CORE.DAL.Entities.Comment comment = new CORE.DAL.Entities.Comment();
            using (IObjectManager OM = CP.Helper().GetServicesManager().CreateProxy<IObjectManager>(ExecutionIdentity.CurrentUser))
            {
                QueryRequest QR = new QueryRequest();
                QR.ObjectType = new ObjectTypeRef() { Name = "Comment" };
                QR.Condition = $"'Artifact ID' == {DocumentAI}";
                QR.Fields = new List<FieldRef>() {
                    new FieldRef() { Name = "Comment"},
                    new FieldRef() { Name = "System Created On"}
                };
                var task = OM.QueryAsync(CP.Helper().GetActiveCaseID(), QR, 1, int.MaxValue);
                task.Wait();
                comment.Name = task.Result.Objects.FirstOrDefault().FieldValues[0].Value.ToString();
                comment.CreatedOn = task.Result.Objects.FirstOrDefault().FieldValues[1].Value.ToString();

            }

            return Json(comment, JsonRequestBehavior.AllowGet);
        }




    }
}
