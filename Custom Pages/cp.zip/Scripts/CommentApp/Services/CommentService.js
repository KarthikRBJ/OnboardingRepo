﻿(function () {

    var commentService = function ($http) {


        var getCommentsChilds = function (artifactId) {
            return $http.get("http://192.168.0.148/Relativity/CustomPages/b9c4168d-a204-4478-b15b-89110f7abebb/Home/GetCommentReplys/?artifactId=" + artifactId)
                  .then(function (response) {
                      return response.data;
                  });
        };

        
        return {
            getCommentsChilds: getCommentsChilds,
        };

    };


    var module = angular.module("commentApp");
    module.factory("commentService", commentService);

}());