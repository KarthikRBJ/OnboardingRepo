﻿(function () {


    var app = angular.module('commentApp', []);

    //app.config(function ($routeProvider) {
    //    //$routeProvider
    //    //      .when("/commentApp", {
    //    //          templateUrl: "main.html",
    //    //          controller: "appController"
    //    //      })
    //    //      .when("/documentList", {
    //    //          templateUrl: "documentList.html",
    //    //          controller: "documentController"
    //    //      })
    //    //      //.when("/repos/:username/:repo", {
    //    //      //    templateUrl: "repoContributors.html",
    //    //      //    controller: "repoContributorsController"
    //    //      //})
    //    //      //.otherwise({ redirectTo: "/main" })

    //});

}());