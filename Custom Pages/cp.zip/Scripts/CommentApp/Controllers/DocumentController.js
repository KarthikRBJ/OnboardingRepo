﻿(function () {


    var app = angular.module('commentApp');

    var documentController = function ($scope, documentService) {



    };


    app.controller("documentController", ["$scope", "documentService", documentController])
}());