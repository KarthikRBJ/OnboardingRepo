﻿(function () {


    var app = angular.module('commentApp');

    var commentController = function ($scope, commentService) {



    };


    app.controller("commentController", ["$scope", "commentService", commentController])
}());